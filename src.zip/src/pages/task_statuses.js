export default function TaskStatuses() {
    return (
      <div>
        <h1>Task Statuses</h1>
      </div>
    );
  }
  