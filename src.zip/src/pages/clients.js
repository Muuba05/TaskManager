import { useState, useEffect } from 'react';

export default function Clients() {
  const [clients, setClients] = useState([]);

  useEffect(() => {
    async function fetchClients() {
      const res = await fetch('/api/clients');
      const data = await res.json();
      setClients(data);
    }
    fetchClients();
  }, []);

  return (
    <div>
      <h1>Clients</h1>
      {clients.length === 0 ? (
        <p>No clients available.</p>
      ) : (
        <ul>
          {clients.map((client) => (
            <li key={client.client_id}>
              <h2>{client.name}</h2>
              <p>Telephone Number: {client.telephone_number}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
